
INTRODUCTION
============
AmigaGuide Windows Viewer (AGWViewer) (Freeware)

A tool that will display and convert any AmigaGuide .guide file and let you browse around just as the original AmigaGuide viewer for Amiga machines. But, naturally, it features more than the original, such as powerful search, automated index generator, conversion to HTML/TXT/PDF, fixes/workarounds for cranky .guide files, PowerPacker (PP20) and XPK decompressing on the fly!

Works on any Windows Operating System (Win95/98 will only convert, since internal html browser engine is not supported).

Outputs are: HTML, TXT or PDF (via printing text file)

A portable version is also available (but no .guide file type will be automatically assigned naturally as this is a feature of the InnoSetup installer script).



THINGS TO KNOW
==============
Tested and works fine with WinME/Win2000/2003/XP/Vista/Win7
Limited funcationality in Win95/98, but converts and exports to .HTML and TXT including Powerpacker support.
Require WinUAE v2.3.1 (or lower, not tested) for decompressing XPK compressed guides, works transparently, just config path and rom file.
Will ignore (hopefully) V40 tags and convert it to V39 look.



CONTACT
=======
post@stone-oakvalley-studios.com
http://www.stone-oakvalley-studios.com/index_software.php
http://www.dirtcellar.net/phpBB3/viewtopic.php?f=21&t=730




FUTURE
======
I suspect I won't be doing any consideration into improving the current V1.0 version as it seems to be stable for a wide range of guides tested. It should be noted that some newer AmigaGuide (v39+) might show leftover codes or strange output (in that case I will do an update to remove V40 tags). This software was generally coded for my own needs and which resulted in beeing compatible with the older Amiga OS like 2.0, 2.1, 3.0 and 3.1. In other words, this was just a side project and not much dedication will be used or available to release further versions.

Taking these notes into consideration it is anyway a very descent and fully working AmigaGuide viewer for any Windows OS system, and I'm sure you can find other software on Linux or Windows that will do the job better (if you dig very deep), but as of 2010-2011 when I googled around there weren't any suitable software to do what this software does in my humble opinion. That's all!




HISTORY
=======

v1.2 - 10 Jan 2011.
- Added a filter for guides where space was replaced by TAB instead. Most likely due to manual/hand edited guides. Now it will show buttons as intended again. Reported by user. 
- Changed "Show Warnings" button to "Show Warnings (on/off)" to make it clear it is a toggle button functionality. Click once= show window, click once more=hide window.


v1.1 - 15 June 2011.
- Added more support for V40 AmigaGuide tags (ergo, will just ignore, fallback mode to v39 look)
- Increased the error command storage from 10000 to 20000 errors, so that certain V40 will probably load, but will be filled with debug information to detect possible removal filters for an update to the next AGWViewer version
- Added a link to this document on the menu.



v1.0 - 23 April 2011.
- Replaced xpkGZIP.library so unpacking seems to work good now, v0.99 would be stuck in a crazy endless crazy loop generating bad filenames. No danger.
- Small redesign of top button strip so all of them show on a 800x600 resolution too.
- Added some support for V40 AmigaGuide tags (ergo, will just ignore, fallback mode to v39 look)



v0.99beta - April 2011:
- Even more filtering and bugtesting performed, several hours of detailed surveilance
- Added History window to menu 
- Added Automatic INDEX creator of all buttons (overrides any embedded INDEX the original author did, seldom never did, and mine's more trustable and complete!)
- Added XPK unpacking support via transparent loading of .adf image into a known winuae config that the user gives us, then loads up the winuae!
- Beta Release Version!



v0.98 - February 2011: 
- Added Powerpacker unpacking support, works fully transparent
- Added title support on viewer window, follows the @TITLE tag or create own automatically!
- Squeezed a lot of scanning bugs and workarounds for cranky written .guides = a debug mess insanity for days



v0.97 - February 2011:
- Added search And browse functions



v0.96 - February 2011:
- Added more scanning functions To remove bad chars, bad output, bad amigaguide files etc.



v0.90 November 2010:
- Finally a useable internal working version at a beta stage at least.
